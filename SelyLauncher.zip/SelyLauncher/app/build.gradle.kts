plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sely.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sely.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-foundation"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Sely QR/Barcode Center: CameraX for the live preview + ML Kit's
    // on-device barcode model for decoding. Both are Google's official,
    // current-generation libraries for this (ML Kit replaced the older
    // ZXing-based approach most tutorials still show).
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")

    // Sely Wallpaper System: WorkManager drives scheduled wallpaper
    // rotation (Android enforces a 15-minute minimum periodic interval —
    // this project uses a 24h period for "daily wallpaper", not a fake
    // shorter one).
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
