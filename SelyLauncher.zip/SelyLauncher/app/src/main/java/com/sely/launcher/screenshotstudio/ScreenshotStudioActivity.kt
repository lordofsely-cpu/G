package com.sely.launcher.screenshotstudio

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivityScreenshotStudioBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Screenshot Studio (spec section 19).
 *
 * Accepts an image via ACTION_VIEW/ACTION_EDIT with a content Uri (File
 * Hub's "Edit" action on an image passes one this way) or falls back to
 * the system picker if opened with nothing. Every save writes a NEW
 * image to MediaStore (Pictures/Sely) rather than overwriting the
 * source — non-destructive editing, matching how every real photo
 * editor behaves.
 */
class ScreenshotStudioActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScreenshotStudioBinding
    private val pickImageRequestCode = 801

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScreenshotStudioBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applyTheme()

        binding.canvas.pendingTapListener = { x, y -> promptForText(x, y) }

        wireToolbar()

        val incomingUri: Uri? = intent.data
        if (incomingUri != null) {
            loadImage(incomingUri)
        } else {
            pickImage()
        }
    }

    private fun applyTheme() {
        binding.studioRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.emptyState.setTextColor(ThemeManager.textSecondary(this))
        binding.toolbar.setBackgroundColor(ThemeManager.backgroundColor(this))
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(intent, pickImageRequestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImageRequestCode) {
            val uri = data?.data
            if (uri != null) loadImage(uri) else if (binding.canvas.workingBitmap == null) finish()
        }
    }

    private fun loadImage(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream).copy(android.graphics.Bitmap.Config.ARGB_8888, true)
                binding.canvas.workingBitmap = bitmap
                binding.emptyState.visibility = android.view.View.GONE
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open that image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun wireToolbar() {
        binding.toolDraw.setOnClickListener { binding.canvas.tool = EditTool.DRAW }
        binding.toolBlur.setOnClickListener { binding.canvas.tool = EditTool.BLUR }
        binding.toolText.setOnClickListener { binding.canvas.tool = EditTool.TEXT }

        binding.toolCrop.setOnClickListener {
            if (binding.canvas.tool == EditTool.CROP && binding.canvas.hasCropSelection()) {
                confirmDestructiveTransform { binding.canvas.applyPendingCrop() }
            } else {
                binding.canvas.tool = EditTool.CROP
                Toast.makeText(this, "Drag to select a crop area, then tap Crop again", Toast.LENGTH_SHORT).show()
            }
        }

        binding.toolRotate.setOnClickListener {
            confirmDestructiveTransform { binding.canvas.rotate90() }
        }

        binding.toolUndo.setOnClickListener { binding.canvas.undoLast() }

        binding.toolSave.setOnClickListener { saveEditedImage(share = false) }
        binding.toolShare.setOnClickListener { saveEditedImage(share = true) }
    }

    /** Rotate/crop clear in-progress overlays (see MarkupCanvasView's doc) — warn once before doing it. */
    private fun confirmDestructiveTransform(action: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("This clears drawings and text")
            .setMessage("Rotating or cropping resets any markup added so far. Continue?")
            .setPositiveButton("Continue") { _, _ -> action() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptForText(x: Float, y: Float) {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Add text")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text?.toString().orEmpty()
                if (text.isNotBlank()) binding.canvas.addText(x, y, text)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveEditedImage(share: Boolean) {
        val flattened = binding.canvas.renderFlattenedBitmap()
        if (flattened == null) {
            Toast.makeText(this, "Nothing to save", Toast.LENGTH_SHORT).show()
            return
        }

        val filename = "Sely_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Sely")
        }

        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Couldn't save image", Toast.LENGTH_SHORT).show()
            return
        }

        contentResolver.openOutputStream(uri)?.use { out ->
            flattened.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)
        }

        Toast.makeText(this, "Saved to Pictures/Sely", Toast.LENGTH_SHORT).show()

        if (share) {
            com.sely.launcher.sharehub.ShareHub.open(this, "image/jpeg", streamUri = uri)
        }
    }
}
