package com.sely.launcher.clock

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivityClockPickerBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Clock System — style picker. Each row is a live, ticking preview
 * (the same ClockWidgetView used on Home), not a static screenshot, so
 * what's shown is exactly what will appear once selected.
 */
class ClockPickerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityClockPickerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityClockPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        buildRows()
    }

    override fun onResume() {
        super.onResume()
        binding.clockPickerRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
    }

    private fun buildRows() {
        binding.styleList.removeAllViews()
        val selected = ClockPrefs.getStyle(this)
        val textColor = ThemeManager.textPrimary(this)
        val accentColor = ThemeManager.accentColor(this)

        ClockStyle.values().forEach { style ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(20), dp(16), dp(20))
                setBackgroundResource(com.sely.launcher.R.drawable.bg_glass_card)
                val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(120))
                params.bottomMargin = dp(14)
                layoutParams = params
            }

            val preview = ClockWidgetView(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70))
                applyStyle(style, textColor, accentColor)
            }
            val label = TextView(this).apply {
                text = if (style == selected) "${style.label} ✓" else style.label
                setTextColor(if (style == selected) accentColor else ThemeManager.textSecondary(this@ClockPickerActivity))
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            }

            row.addView(preview)
            row.addView(label)
            row.setOnClickListener {
                ClockPrefs.setStyle(this, style)
                buildRows()
            }
            binding.styleList.addView(row)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
