package com.sely.launcher.wallpaper

import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.Constraints
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.sely.launcher.databinding.ActivityWallpaperBinding
import com.sely.launcher.theme.ThemeManager
import java.util.concurrent.TimeUnit

/**
 * Sely Wallpaper System (spec section 43).
 *
 * Built: static wallpaper picking with real Blur/Dim effects baked into
 * the image (see WallpaperEffects), and genuinely separate Home/Lock
 * wallpapers via WallpaperManager.setBitmap(..., which) on API 24+
 * (🟢 real official API for this — Android added it specifically so
 * apps could do exactly this). Daily rotation across a saved set of
 * images via WorkManager (see WallpaperRotationWorker for the honest
 * timing caveat).
 *
 * Not built here: true parallax/motion wallpaper effects. Real
 * multi-layer parallax that responds to home-screen swipes requires
 * implementing an actual Android Live Wallpaper (a WallpaperService
 * with an Engine that handles onOffsetsChanged) — a distinct component
 * type from anything else in this app, and a substantial feature in its
 * own right rather than a setting to flip here.
 */
class WallpaperActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWallpaperBinding
    private var selectedBitmap: Bitmap? = null
    private val pickImageCode = 1001
    private val pickRotationSetCode = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.blurSlider.progress = WallpaperRotationStore.blurStrength(this)
        binding.dimSlider.progress = WallpaperRotationStore.dimPercent(this)

        binding.pickImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(intent, pickImageCode)
        }

        binding.blurSlider.setOnSeekBarChangeListener(simpleSeekListener { updatePreview() })
        binding.dimSlider.setOnSeekBarChangeListener(simpleSeekListener { updatePreview() })

        binding.setHome.setOnClickListener { applyWallpaper(home = true, lock = false) }
        binding.setLock.setOnClickListener { applyWallpaper(home = false, lock = true) }
        binding.setBoth.setOnClickListener { applyWallpaper(home = true, lock = true) }

        binding.rotationSwitch.setOnCheckedChangeListener { _, checked ->
            WallpaperRotationStore.setRotationEnabled(this, checked)
            if (checked) scheduleRotationWork() else WorkManager.getInstance(this).cancelUniqueWork("sely_wallpaper_rotation")
        }

        binding.pickRotationSet.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, pickRotationSetCode)
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        binding.rotationSwitch.isChecked = WallpaperRotationStore.rotationEnabled(this)
        binding.rotationCount.text = "${WallpaperRotationStore.getUris(this).size} images in rotation"
    }

    private fun applyTheme() {
        val bg = ThemeManager.backgroundColor(this)
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        binding.wallpaperRoot.setBackgroundColor(bg)
        binding.screenTitle.setTextColor(textPrimary)
        binding.blurLabel.setTextColor(textSecondary)
        binding.dimLabel.setTextColor(textSecondary)
        binding.rotationHeader.setTextColor(textPrimary)
        binding.rotationNote.setTextColor(textSecondary)
        binding.rotationCount.setTextColor(textPrimary)
    }

    private fun simpleSeekListener(onChange: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange()
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            pickImageCode -> {
                val uri = data?.data ?: return
                contentResolver.openInputStream(uri)?.use { stream ->
                    selectedBitmap = BitmapFactory.decodeStream(stream)
                    updatePreview()
                }
            }
            pickRotationSetCode -> {
                val uris = mutableListOf<Uri>()
                data?.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } ?: data?.data?.let { uris.add(it) }

                uris.forEach { uri ->
                    // Persist access across restarts/reboots — see
                    // WallpaperRotationStore's class doc for why this
                    // matters for a background-scheduled feature.
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                WallpaperRotationStore.setUris(this, uris.map { it.toString() })
                binding.rotationCount.text = "${uris.size} images in rotation"
                Toast.makeText(this, "Rotation set updated", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updatePreview() {
        val base = selectedBitmap ?: return
        val blurred = WallpaperEffects.applyBlur(base, binding.blurSlider.progress)
        val final = WallpaperEffects.applyDim(blurred, binding.dimSlider.progress)
        binding.preview.setImageBitmap(final)
        WallpaperRotationStore.setBlurStrength(this, binding.blurSlider.progress)
        WallpaperRotationStore.setDimPercent(this, binding.dimSlider.progress)
    }

    private fun applyWallpaper(home: Boolean, lock: Boolean) {
        val base = selectedBitmap
        if (base == null) {
            Toast.makeText(this, "Choose an image first", Toast.LENGTH_SHORT).show()
            return
        }
        val blurred = WallpaperEffects.applyBlur(base, binding.blurSlider.progress)
        val finalBitmap = WallpaperEffects.applyDim(blurred, binding.dimSlider.progress)
        val wallpaperManager = WallpaperManager.getInstance(this)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                var which = 0
                if (home) which = which or WallpaperManager.FLAG_SYSTEM
                if (lock) which = which or WallpaperManager.FLAG_LOCK
                wallpaperManager.setBitmap(finalBitmap, null, true, which)
            } else {
                // Pre-N Android has no separate lock-screen wallpaper API —
                // setBitmap always applies to both.
                wallpaperManager.setBitmap(finalBitmap)
            }
            Toast.makeText(this, "Wallpaper updated", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't set wallpaper: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleRotationWork() {
        // Sely Performance System (Battery mode): a real, enforced
        // WorkManager constraint — not a cosmetic label — restricts
        // rotation to charging windows when the user has selected it.
        val constraints = Constraints.Builder()
            .setRequiresCharging(com.sely.launcher.performance.PerformanceModeStore.requireChargingForBackgroundWork(this))
            .build()
        val request = PeriodicWorkRequestBuilder<WallpaperRotationWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "sely_wallpaper_rotation", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }
}
