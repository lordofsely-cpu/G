package com.sely.launcher.sharehub

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class ShareTargetAdapter(
    private val context: Context,
    private val targets: List<ShareTarget>,
    private val onClick: (ShareTarget) -> Unit
) : RecyclerView.Adapter<ShareTargetAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = targets.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val target = targets[position]
        holder.icon.setImageDrawable(target.icon)
        holder.label.text = target.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.itemView.setOnClickListener { onClick(target) }
    }
}
