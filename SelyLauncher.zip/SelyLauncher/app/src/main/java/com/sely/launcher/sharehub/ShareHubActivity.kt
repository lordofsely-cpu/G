package com.sely.launcher.sharehub

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.databinding.ActivityShareHubBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Share Hub (spec section 18) — see ShareHubRepository's class doc
 * for why the target list is resolved live via PackageManager rather
 * than hardcoded. Tapping a target launches it directly with the same
 * content via an explicit intent (skipping a second system chooser),
 * which is the standard pattern custom share UIs use.
 */
class ShareHubActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MIME_TYPE = "mimeType"
        const val EXTRA_TEXT = "text"
        const val EXTRA_STREAM = "stream"
    }

    private lateinit var binding: ActivityShareHubBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShareHubBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.scrim.setOnClickListener { finish() }

        binding.shareHubRoot.setBackgroundColor(ThemeManager.dockColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.emptyState.setTextColor(ThemeManager.textSecondary(this))

        val mimeType = intent.getStringExtra(EXTRA_MIME_TYPE) ?: "*/*"
        val text = intent.getStringExtra(EXTRA_TEXT)
        val streamUri = intent.getParcelableExtra<Uri>(EXTRA_STREAM)

        val sendIntent = buildSendIntent(mimeType, text, streamUri)
        val targets = ShareHubRepository.resolveTargets(this, sendIntent)

        binding.emptyState.visibility = if (targets.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.targetGrid.layoutManager = GridLayoutManager(this, 4)
        binding.targetGrid.adapter = ShareTargetAdapter(this, targets) { target ->
            val explicitIntent = buildSendIntent(mimeType, text, streamUri).apply {
                component = ComponentName(target.packageName, target.activityName)
            }
            startActivity(explicitIntent)
            finish()
        }
    }

    private fun buildSendIntent(mimeType: String, text: String?, streamUri: Uri?): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            text?.let { putExtra(Intent.EXTRA_TEXT, it) }
            streamUri?.let {
                putExtra(Intent.EXTRA_STREAM, it)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }
}
