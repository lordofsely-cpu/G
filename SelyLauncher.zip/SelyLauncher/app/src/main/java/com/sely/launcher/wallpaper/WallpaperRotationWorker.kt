package com.sely.launcher.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.work.Worker
import androidx.work.WorkerParameters

/**
 * Sely Wallpaper System — "time-based wallpaper changes" (spec §43).
 *
 * 🟡 Honest note on timing: Android's WorkManager (and JobScheduler
 * underneath it) enforces a hard 15-minute minimum for periodic work,
 * and even that is a *guideline* Doze/battery-optimization can delay
 * further — there is no way for any app to guarantee an exact-time
 * background wake-up without the user exempting it from battery
 * optimization. This is scheduled as a 24-hour period ("daily
 * wallpaper"), which is realistic and battery-respectful, rather than
 * promising precise timing the OS won't actually deliver.
 */
class WallpaperRotationWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val context = applicationContext
        if (!WallpaperRotationStore.rotationEnabled(context)) return Result.success()

        val uriString = WallpaperRotationStore.nextUri(context) ?: return Result.success()
        return try {
            val uri = Uri.parse(uriString)
            val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: return Result.failure()

            val blurred = WallpaperEffects.applyBlur(bitmap, WallpaperRotationStore.blurStrength(context))
            val finalBitmap = WallpaperEffects.applyDim(blurred, WallpaperRotationStore.dimPercent(context))

            val wallpaperManager = WallpaperManager.getInstance(context)
            wallpaperManager.setBitmap(finalBitmap)
            Result.success()
        } catch (e: Exception) {
            // A rotation Uri can go stale (file deleted, permission
            // revoked) — fail this one run rather than crash; the next
            // scheduled run tries the next image in the set.
            Result.failure()
        }
    }
}
