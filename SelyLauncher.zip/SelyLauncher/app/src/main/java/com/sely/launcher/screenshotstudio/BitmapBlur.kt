package com.sely.launcher.screenshotstudio

import android.graphics.Bitmap

/**
 * A genuine box blur applied to actual pixel data — used by the
 * "Blur" tool to redact part of a screenshot. Not a translucent overlay
 * drawn on top (which wouldn't actually hide the underlying content
 * once flattened) — the source pixels themselves are averaged and
 * replaced, so the blurred region is really gone from the saved image.
 *
 * Kept as a simple, dependency-free box blur (average of a radius-N
 * neighborhood per pixel) rather than pulling in RenderScript (deprecated)
 * or a GPU shader — for the small brush-sized regions this tool touches,
 * a plain box blur is fast enough and has no extra dependency.
 */
object BitmapBlur {

    fun blurRegion(bitmap: Bitmap, centerX: Int, centerY: Int, brushRadius: Int, blurStrength: Int = 6) {
        val left = (centerX - brushRadius).coerceIn(0, bitmap.width - 1)
        val top = (centerY - brushRadius).coerceIn(0, bitmap.height - 1)
        val right = (centerX + brushRadius).coerceIn(0, bitmap.width - 1)
        val bottom = (centerY + brushRadius).coerceIn(0, bitmap.height - 1)
        if (right <= left || bottom <= top) return

        val width = right - left + 1
        val height = bottom - top + 1
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, left, top, width, height)

        val result = IntArray(pixels.size)
        for (y in 0 until height) {
            for (x in 0 until width) {
                var r = 0; var g = 0; var b = 0; var count = 0
                for (dy in -blurStrength..blurStrength) {
                    val ny = y + dy
                    if (ny < 0 || ny >= height) continue
                    for (dx in -blurStrength..blurStrength) {
                        val nx = x + dx
                        if (nx < 0 || nx >= width) continue
                        val p = pixels[ny * width + nx]
                        r += (p shr 16) and 0xFF
                        g += (p shr 8) and 0xFF
                        b += p and 0xFF
                        count++
                    }
                }
                result[y * width + x] = (0xFF shl 24) or ((r / count) shl 16) or ((g / count) shl 8) or (b / count)
            }
        }
        bitmap.setPixels(result, 0, width, left, top, width, height)
    }
}
